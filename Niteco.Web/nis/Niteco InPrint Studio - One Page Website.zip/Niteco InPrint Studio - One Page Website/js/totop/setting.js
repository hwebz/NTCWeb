		$(document).ready(function() {
			$().UItoTop({ easingType: 'easeOutQuart' });
		});