(function($) {
	'use strict';

	$('.youTubeEmbed').youTubeEmbed("https://www.youtube.com/watch?v=mdfMT5Zi8Eo");

})(jQuery);
