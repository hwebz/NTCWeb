(function($) {
	'use strict';
	$(".player").mb_YTPlayer();
})(jQuery);