$(window).load(function(){
	'use strict';
	$(".scrolltop").jCarouselLite({
		vertical: true,
		hoverPause:true,
		visible: 1,
		auto:6500,
		speed:1000
	});
});