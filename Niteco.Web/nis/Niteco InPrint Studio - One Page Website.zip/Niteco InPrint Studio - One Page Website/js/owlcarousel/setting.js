(function($) {
	'use strict';
      $("#client-wrapper, #owl-testimoni").owlCarousel({
        autoPlay : false,
        stopOnHover : true,
		pagination : false,
        navigation:true,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
      });
})(jQuery);