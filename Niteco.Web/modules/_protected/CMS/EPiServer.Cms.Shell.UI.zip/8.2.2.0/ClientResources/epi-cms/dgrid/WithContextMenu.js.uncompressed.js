﻿define("epi-cms/dgrid/WithContextMenu", [
    // Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "epi/shell/widget/ContextMenu",
    "epi/shell/DestroyableByKey"
], function(
    declare,
    lang,
    domClass,
    ContextMenu,
    DestroyableByKey) {

    return declare([DestroyableByKey], {
        // summary:
        //      Extension for dgrid that adds an context menu and events.
        //
        // tags:
        //      public
        
        contextMenu: null,

        postCreate: function() {
            this.inherited(arguments);
            this.contextMenu = this.contextMenu || new ContextMenu({ category: "context" });
            this.ownByKey(this.contextMenu, this.contextMenu);
            this._setupGridEvents();
        },

        startup: function () {
            this.inherited(arguments);
            this.contextMenu.startup();
        },

        _setupGridEvents: function() {
            // summary:
            //      Initialization of events on the grid.
            // tags:
            //      private

            this.ownByKey("contextMenuClick", this.on(".epi-iconContextMenu:click", lang.hitch(this, this.onContextMenuClick)));
        },

        onContextMenuClick: function(e) {
            // summary:
            //      Triggered when a click on the grids context menu is registered.
            // remarks: 
            //      It will open the context menu.
            // tags:
            //      protected

            this.contextMenu.scheduleOpen(this, null, {
                x: e.pageX,
                y: e.pageY
            });
        }
    });

});